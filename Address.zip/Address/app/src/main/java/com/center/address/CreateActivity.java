package com.center.address;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class CreateActivity extends AppCompatActivity {
    public static final String county1 = "countyKey";
    public static final String coCode1 = "coCodeKey";
    public static final String proCode1 = "proCodeKey";
    public static final String region1 = "regionKey";
    public static final String regionNumber1 = "regionNumberKey";
    public static final String MyPREFERENCES = "MyPrefs" ;

    SharedPreferences sharedpreferences;
    String selectedCounty, coCode, proCode, selectedRegion, regionCode, roadName, roadNumber, routeNumber;
    ImageView homeImg, refreshImg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);

        sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        selectedCounty = sharedpreferences.getString(county1,"");
        coCode = sharedpreferences.getString(coCode1,"");
        proCode = sharedpreferences.getString(proCode1,"");
        selectedRegion = sharedpreferences.getString(region1,"");
        regionCode = sharedpreferences.getString(regionNumber1,"");

        homeImg=(ImageView) findViewById(R.id.img_home);
        refreshImg=(ImageView) findViewById(R.id.img_refresh);

        Bundle loca=getIntent().getExtras();
        if (loca != null) {
            roadName=String.valueOf(loca.getCharSequence("roadname"));
            roadNumber=String.valueOf(loca.getCharSequence("roadnumber"));
            routeNumber=String.valueOf(loca.getCharSequence("routenumber"));
        }


        homeImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(CreateActivity.this, MainActivity.class));
            }
        });

        refreshImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(CreateActivity.this, CreateActivity.class));
            }
        });
    }
}
